"""Customer churn inference API."""
