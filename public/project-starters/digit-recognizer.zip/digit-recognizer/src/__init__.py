"""Digit classifier student implementation."""
